@extends('layouts.master')
@section('title') BikeShop|ประเภทสินค้า @stop
@section('content')    

<h1>รายการสินค้า</h1>
<div class="panel panel-default">
<div class="panel-heading">
<div class="panel-title"><strong>รายการ</strong></div>
</div>
<div class=panel-body></div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-11 col-md-offset-0.5">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>รหัส</th>
                        <th>ประเภท</th>
                        <th>การทํางาน</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($category as $c)
                    <tr>
                        <td>{{ $c->id }}</td>
                        <td>{{ $c->name }}</td>
                        <td> 
                            <a href="#" class="btn btn-info"><i class="fa fa-edit"></i> แก้ไข</a>
                            <a href="#" class="btn btn-danger"><i class="fa fa-trash"></i> ลบ</a>
                        </td>
                    </tr> @endforeach
                    <tfoot>
                    </tfoot>
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection